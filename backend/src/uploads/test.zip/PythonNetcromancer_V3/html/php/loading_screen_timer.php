<script>
            // Use JavaScript to hide the loading screen after 3 seconds
    setTimeout(function() {
        document.getElementById('loadingScreen').style.display = 'none';
    }, 3000);
</script>