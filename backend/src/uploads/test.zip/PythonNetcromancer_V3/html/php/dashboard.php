<div id="loadedContent">
<?php include('php/throughput_plotter.php')?>
<div id='right_panel'>
    <?php include('php/network_scanner.php')?>
</div>
</div>