<div id="loadingScreen" class="loading-container content-display-height conttent-display-full" style="display: flex">
    <span class="loader"></span>

</div>