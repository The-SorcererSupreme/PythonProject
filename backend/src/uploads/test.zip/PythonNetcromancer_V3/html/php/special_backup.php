<div id="loadedContent" style="display: none;">
</div>
<?php
session_start();
$_SESSION["ready"] = "Yes";
?>