<div id="header" class="grid-header">
    <img class="logo" src="img/logo.png" />
    <h1 id="title"><span class="neonText" style="">PYTHON <br>NETCROMANCER</span></h1>
    <h1 id="title"><span class="neonText"></span></h1>
    <a href="php/logout.php">Logout</a>
</div>